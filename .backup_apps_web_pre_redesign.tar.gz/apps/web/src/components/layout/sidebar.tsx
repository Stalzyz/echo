"use client"

import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { useState } from "react"
import { getNavItemsByRole, NavItem, Role } from "@/config/navigation"
import { useOrganization } from "@/context/OrganizationContext"
import { cn } from "@/lib/utils"
import { useSession, signOut } from "next-auth/react"
import { 
  ChevronDown, ChevronRight, Menu, X, ShieldCheck, Moon, Sun, 
  LayoutDashboard, BookOpen, Briefcase, MessageSquare, Layers, DollarSign, Bell, LogOut, User
} from "lucide-react"
import dynamic from "next/dynamic"
import Image from "next/image"

const RealtimeIndicator = dynamic(() => import("@/components/RealtimeIndicator"), { ssr: false })

import { NotificationMenu } from "./NotificationMenu"
import { TimerWidget } from "./TimerWidget"

function BrandLogo({ url, name, size = 32 }: { url?: string | null; name: string; size?: number }) {
  const [hasError, setHasError] = useState(false)
  
  if (url && !hasError) {
    return (
      <div 
        style={{ width: size, height: size }}
        className="rounded-xl overflow-hidden shrink-0 border border-dash-border-strong bg-white/5 flex items-center justify-center p-0.5"
      >
        <img 
          src={url} 
          alt={name} 
          onError={() => setHasError(true)} 
          className="w-full h-full object-contain" 
        />
      </div>
    )
  }

  return (
    <div 
      style={{ width: size, height: size }}
      className="rounded-xl bg-dash-bg-elevated border border-dash-border-strong flex items-center justify-center shrink-0 shadow-[0_0_15px_rgba(255,255,255,0.05)]"
    >
      <ShieldCheck className="w-4 h-4 text-blue-400" strokeWidth={2} />
    </div>
  )
}

function OrgHeader() {
  const org = useOrganization()

  return (
    <div className="flex h-16 items-center px-6 gap-3 relative z-10">
      <BrandLogo url={org.logoUrl} name={org.name} size={32} />
      <span className="text-lg font-bold tracking-tight">{org.name}</span>
      <div className="ml-auto flex items-center gap-2">
        <TimerWidget />
        <NotificationMenu />
        <RealtimeIndicator />
      </div>
    </div>
  )
}


function NavGroup({ item, pathname, onClose }: { item: NavItem; pathname: string; onClose?: () => void }) {
  const Icon = item.icon
  const router = useRouter()
  const isGroupActive = pathname === item.href || pathname?.startsWith(`${item.href}/`)
  const [open, setOpen] = useState(isGroupActive)

  if (!item.children || item.children.length === 0) {
    return (
      <Link
        href={item.href}
        onClick={onClose}
        className={cn(
          "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all group",
          isGroupActive
            ? "bg-blue-500/10 text-blue-400 shadow-[inset_2px_0_0_0_rgba(59,130,246,1)]"
            : "text-dash-text-primary/50 hover:bg-dash-bg-elevated hover:text-dash-text-primary"
        )}
      >
        <Icon className={cn("h-4 w-4 shrink-0 transition-colors", isGroupActive ? "text-blue-400" : "text-dash-text-primary/30 group-hover:text-dash-text-primary/70")} />
        {item.title}
      </Link>
    )
  }

  return (
    <div className="mb-1">
      {/* Group header — toggles open/close AND navigates */}
      <button
        onClick={() => {
          setOpen(!open)
          if (item.href) {
            router.push(item.href)
            if (onClose) onClose()
          }
        }}
        className={cn(
          "w-full flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all group",
          isGroupActive
            ? "text-dash-text-primary font-bold"
            : "text-dash-text-primary/50 hover:bg-dash-bg-elevated hover:text-dash-text-primary"
        )}
      >
        <Icon className={cn("h-4 w-4 shrink-0 transition-colors", isGroupActive ? "text-blue-400" : "text-dash-text-primary/30 group-hover:text-dash-text-primary/70")} />
        <span className="flex-1 text-left tracking-wide">{item.title}</span>
        {open
          ? <ChevronDown className="h-3.5 w-3.5 shrink-0 opacity-40 group-hover:opacity-100 transition-opacity" />
          : <ChevronRight className="h-3.5 w-3.5 shrink-0 opacity-40 group-hover:opacity-100 transition-opacity" />
        }
      </button>

      {/* Sub items */}
      <div className={cn(
        "grid transition-all duration-200 ease-in-out",
        open ? "grid-rows-[1fr] opacity-100 mt-1" : "grid-rows-[0fr] opacity-0"
      )}>
        <div className="overflow-hidden">
          <div className="ml-5 pl-3 border-l border-dash-border-strong space-y-1">
            {item.children!.map(child => {
              const isChildActive = pathname === child.href
              return (
                <Link
                  key={child.href}
                  href={child.href}
                  onClick={onClose}
                  className={cn(
                    "flex items-center gap-2 rounded-md px-3 py-2 text-xs font-medium transition-all group",
                    isChildActive
                      ? "bg-blue-500/10 text-blue-400"
                      : "text-dash-text-primary/40 hover:bg-dash-bg-elevated hover:text-dash-text-primary"
                  )}
                >
                  <span className={cn("w-1.5 h-1.5 rounded-full transition-all", isChildActive ? "bg-blue-400 shadow-[0_0_8px_rgba(59,130,246,0.8)]" : "bg-dash-border-strong group-hover:bg-dash-bg-elevated0")} />
                  {child.title}
                </Link>
              )
            })}
          </div>
        </div>
      </div>
    </div>
  )
}

export function Sidebar() {
  const pathname = usePathname()
  const { data: session } = useSession()
  const [mobileOpen, setMobileOpen] = useState(false)
  const org = useOrganization()

  let rawRole = session?.user?.role || "INTERN"
  if (rawRole === "Super Admin") rawRole = "SUPER_ADMIN"
  if (rawRole === "Manager") rawRole = "MANAGER"
  if (rawRole === "Staff") rawRole = "STAFF"
  if (rawRole === "Client") rawRole = "CLIENT"
  if (rawRole === "Student") rawRole = "STUDENT"
  if (rawRole === "Vendor") rawRole = "VENDOR"
  if (rawRole === "Intern") rawRole = "INTERN"
  
  const role = rawRole as Role
  
  // Retrieve custom permissions from next-auth session if available
  const customPermissions = (session?.user as any)?.permissions || []
  
  const navItems = getNavItemsByRole(role, customPermissions)

  const getBottomTabs = (role: Role) => {
    switch (role) {
      case "STUDENT":
      case "INTERN":
        return [
          { title: "Home", href: "/dashboard", icon: LayoutDashboard },
          { title: "Courses", href: "/dashboard/lms", icon: BookOpen },
          { title: "Tasks", href: "/dashboard/lms/assignments", icon: Briefcase },
          { title: "Chat", href: "/dashboard/chat", icon: MessageSquare },
        ]
      case "CLIENT":
        return [
          { title: "Home", href: "/dashboard", icon: LayoutDashboard },
          { title: "Billing", href: "/dashboard/finance/revenue", icon: DollarSign },
          { title: "Board", href: "/dashboard/projects", icon: Briefcase },
          { title: "Chat", href: "/dashboard/chat", icon: MessageSquare },
        ]
      case "VENDOR":
        return [
          { title: "Home", href: "/dashboard", icon: LayoutDashboard },
          { title: "Board", href: "/dashboard/projects", icon: Briefcase },
          { title: "Chat", href: "/dashboard/chat", icon: MessageSquare },
          { title: "Alerts", href: "/dashboard/notifications", icon: Bell },
        ]
      default: // SUPER_ADMIN, MANAGER, STAFF
        return [
          { title: "Home", href: "/dashboard", icon: LayoutDashboard },
          { title: "CRM", href: "/dashboard/crm", icon: Layers },
          { title: "Board", href: "/dashboard/projects", icon: Briefcase },
          { title: "Chat", href: "/dashboard/chat", icon: MessageSquare },
        ]
    }
  }

  const sidebarContent = (
    <div className="flex flex-1 w-full flex-col min-h-0 overflow-hidden bg-dash-bg-surface/40 backdrop-blur-2xl text-dash-text-primary font-sans relative">
      
      {/* Background ambient glow inside sidebar */}
      <div className="absolute top-0 left-0 w-full h-64 bg-blue-500/5 blur-[100px] pointer-events-none" />

      {/* Header / Logo — Dynamic Whitelabel */}
      <OrgHeader />

      {/* Role badge */}
      <div className="px-6 py-4 relative z-10">
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-dash-bg-elevated border border-dash-border-subtle w-fit">
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-[10px] font-mono font-bold uppercase tracking-widest text-dash-text-primary/60">
            {role} CLEARANCE
          </span>
        </div>
      </div>

      {/* Nav items */}
      <div className="flex-1 min-h-0 overflow-y-auto custom-scrollbar px-3 space-y-1 pb-6 relative z-10">
        {navItems.map(item => (
          <NavGroup key={item.href} item={item} pathname={pathname} onClose={() => setMobileOpen(false)} />
        ))}
      </div>

      {/* User footer */}
      <div className="p-4 relative z-10 border-t border-dash-border-subtle bg-gradient-to-t from-black/60 to-transparent">
        <div className="flex items-center gap-3">
          <div onClick={() => signOut()} className="flex-1 flex items-center gap-3 p-3 rounded-xl hover:bg-dash-bg-elevated transition-colors cursor-pointer border border-transparent hover:border-dash-border-strong" title="Click to logout">
            <div className="h-10 w-10 rounded-full bg-gradient-to-br from-blue-500/20 to-purple-500/20 border border-dash-border-strong flex items-center justify-center text-dash-text-primary font-bold text-sm shrink-0">
              {session?.user?.name?.charAt(0) || "U"}
            </div>
            <div className="flex flex-col min-w-0">
              <span className="text-sm font-semibold leading-none truncate tracking-wide text-dash-text-primary/90">{session?.user?.name || "System User"}</span>
              <span className="text-xs text-dash-text-primary/40 mt-1.5 truncate font-mono">{session?.user?.email}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )

  return (
    <>
      {/* Desktop sidebar */}
      <div className="print:hidden hidden md:flex h-screen w-72 flex-col border-r border-dash-border-strong shrink-0 bg-dash-bg-base relative z-20 shadow-[4px_0_24px_rgba(0,0,0,0.5)] overflow-hidden">
        {sidebarContent}
      </div>

      {/* Mobile Top Header Bar */}
      <div className="print:hidden md:hidden fixed top-0 left-0 right-0 h-16 bg-dash-bg-surface/90 backdrop-blur-md border-b border-dash-border-strong z-40 flex items-center justify-between px-5">
        <div className="flex items-center gap-2.5">
          <BrandLogo url={org.logoUrl} name={org.name} size={28} />
          <span className="text-xs font-bold tracking-wider uppercase text-dash-text-primary/90 truncate max-w-[120px]">{org.name}</span>
        </div>
        <div className="flex items-center gap-2.5">
          <NotificationMenu />
          <RealtimeIndicator />
        </div>
      </div>

      {/* Mobile Bottom Tab Bar */}
      <div className="print:hidden md:hidden fixed bottom-0 left-0 right-0 h-16 bg-dash-bg-surface/90 backdrop-blur-md border-t border-dash-border-strong z-40 flex items-center justify-around px-2 shadow-[0_-4px_20px_rgba(0,0,0,0.3)]">
        {getBottomTabs(role).map(tab => {
          const TabIcon = tab.icon
          const isTabActive = pathname === tab.href || (tab.href !== "/dashboard" && pathname?.startsWith(`${tab.href}/`))
          return (
            <Link
              key={tab.href}
              href={tab.href}
              className={cn(
                "flex flex-col items-center justify-center flex-1 h-full gap-1 transition-colors relative",
                isTabActive ? "text-blue-400 font-bold" : "text-dash-text-primary/40"
              )}
            >
              <TabIcon className="w-5 h-5" />
              <span className="text-[8px] uppercase tracking-wider font-bold">{tab.title}</span>
              {isTabActive && <span className="absolute bottom-1 w-5 h-0.5 bg-blue-400 rounded-full" />}
            </Link>
          )
        })}
        <button
          onClick={() => setMobileOpen(true)}
          className="flex flex-col items-center justify-center flex-1 h-full gap-1 transition-colors text-dash-text-primary/40 hover:text-dash-text-primary"
        >
          <Menu className="w-5 h-5" />
          <span className="text-[8px] uppercase tracking-wider font-bold">Menu</span>
        </button>
      </div>

      {/* Mobile drawer overlay */}
      {mobileOpen && (
        <div className="md:hidden fixed inset-0 z-50 flex">
          {/* Backdrop */}
          <div
            className="absolute inset-0 bg-black/80 backdrop-blur-sm transition-opacity"
            onClick={() => setMobileOpen(false)}
          />
          {/* Drawer */}
          <div className="relative w-[85%] max-w-sm h-full flex flex-col shadow-2xl border-r border-dash-border-strong overflow-hidden bg-dash-bg-base">
            <button
              onClick={() => setMobileOpen(false)}
              className="absolute top-5 right-5 z-20 p-2 rounded-full bg-dash-bg-elevated/80 hover:bg-dash-border-strong text-dash-text-primary/70 transition-colors backdrop-blur-md"
            >
              <X className="w-5 h-5" />
            </button>
            {sidebarContent}
          </div>
        </div>
      )}
    </>
  )
}
 
