"use client"

import { useParams } from "next/navigation"
import { ChevronLeft, Download, Send, CheckCircle2, Loader2, ArrowRight, Trash2, Edit, Save, Plus } from "lucide-react"
import Link from "next/link"
import { useApi, fetchApi } from "@/lib/useApi"
import { format } from "date-fns"
import { useOrganization } from "@/context/OrganizationContext"
import { useCurrency } from "@/hooks/useCurrency"

export default function ProposalDetailPage() {
  const params = useParams()
  const proposalId = params.id as string
  const router = import("next/navigation").then(m => m.useRouter)
  const org = useOrganization()
  const { symbol } = useCurrency()

  const { data: proposal, isLoading, mutate } = useApi<any>(`/crm/proposals/${proposalId}`)

  if (isLoading) {
    return (
      <div className="flex flex-col h-full items-center justify-center bg-background/50 text-muted-foreground">
        <Loader2 className="w-8 h-8 animate-spin mb-4" />
        <p>Loading Proposal...</p>
      </div>
    )
  }

  if (!proposal) {
    return (
      <div className="flex flex-col h-full items-center justify-center bg-background/50 text-muted-foreground">
        <p>Proposal not found.</p>
        <Link href="/dashboard/crm/proposals" className="mt-4 text-primary hover:underline">Return to Proposals</Link>
      </div>
    )
  }

  const handlePrint = () => {
    window.print();
  }

  const handleDownloadPDF = async () => {
    // Open the backend PDF endpoint in a new tab
    const pdfUrl = `/api/v1/crm/proposals/${proposalId}/pdf`;
    window.open(pdfUrl, '_blank');
  }

  const markAsSent = async () => {
    let recipientEmail: string | undefined = undefined;
    if (!proposal?.contactId && !proposal?.leadId && !proposal?.contact?.email && !proposal?.lead?.email) {
      const emailInput = window.prompt("This proposal is unassigned. Enter the client's email address to send and publish to their portal:")
      if (!emailInput || !emailInput.trim()) return;
      recipientEmail = emailInput.trim();
    }
    try {
      await fetchApi(`/crm/proposals/${proposalId}/send`, {
        method: "POST",
        body: JSON.stringify({ recipientEmail })
      });
      mutate();
      alert("Proposal securely emailed to the client & published to their portal!");
    } catch (err: any) {
      console.error(err);
      alert(err.message || "Failed to send email");
    }
  }

  const handleDelete = async () => {
    if (!window.confirm("Are you sure you want to delete this proposal?")) return;
    try {
      await fetchApi(`/crm/proposals/${proposalId}`, { method: "DELETE" });
      window.location.href = "/dashboard/crm/proposals";
    } catch (err: any) {
      console.error(err);
      alert(`Failed to delete proposal: ${err.message || String(err)}`);
    }
  }

  const handleSaveAsTemplate = async () => {
    if (!window.confirm("Save this proposal as a reusable template?")) return;
    try {
      await fetchApi(`/crm/proposals/${proposalId}/template`, { method: "POST" });
      mutate();
      alert("Saved as template!");
    } catch (err: any) {
      console.error(err);
      alert("Failed to save as template.");
    }
  }

  const handleDuplicate = async () => {
    if (!window.confirm("Duplicate this proposal?")) return;
    try {
      const duplicated = await fetchApi(`/crm/proposals/${proposalId}/duplicate`, { method: "POST" });
      window.location.href = `/dashboard/crm/proposals/${(duplicated as any).id}/edit`;
    } catch (err: any) {
      console.error(err);
      alert("Failed to duplicate.");
    }
  }

  return (
    <div className="flex flex-col h-full min-h-0 overflow-y-auto bg-background/50 relative">
      <style dangerouslySetInnerHTML={{__html: `
        @media print {
          body * {
            visibility: hidden;
          }
          #printable-proposal, #printable-proposal * {
            visibility: visible;
          }
          #printable-proposal {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            margin: 0;
            padding: 0;
            border: none;
            box-shadow: none;
            background: white !important;
            color: black !important;
          }
          .text-muted-foreground {
            color: #666 !important;
          }
          .text-foreground {
            color: #000 !important;
          }
          .border-border\\/60, .border-border\\/40, .border-border\\/30 {
            border-color: #ddd !important;
          }
        }
      `}} />

      <div className="max-w-4xl w-full mx-auto p-8 relative z-10">
        
        <Link href="/dashboard/crm/proposals" className="inline-flex items-center gap-1.5 text-xs font-medium text-muted-foreground hover:text-foreground transition-colors mb-6 print:hidden">
          <ChevronLeft className="w-3.5 h-3.5" /> Back to Proposals
        </Link>

        {/* Action Header */}
        <div className="flex flex-col md:flex-row md:items-start justify-between mb-8 gap-4 print:hidden">
          <div>
            <h1 className="text-3xl font-bold text-foreground mb-2">{proposal.title}</h1>
            <div className="flex items-center gap-3">
              <span className={`text-xs font-semibold px-2.5 py-1 rounded-full border ${
                proposal.status === 'ACCEPTED' ? 'text-emerald-400 border-emerald-400/20 bg-emerald-400/10' :
                proposal.status === 'DRAFT' ? 'text-slate-400 border-slate-400/20 bg-slate-400/10' :
                proposal.status === 'SENT' ? 'text-blue-400 border-blue-400/20 bg-blue-400/10' :
                'text-amber-400 border-amber-400/20 bg-amber-400/10'
              }`}>
                {proposal.status}
              </span>
              <span className="text-sm text-muted-foreground">Version {proposal.version || 1}</span>
            </div>
          </div>
          <div className="flex gap-3">
            <button onClick={handleDuplicate} className="flex items-center gap-2 bg-indigo-500/10 text-indigo-500 border border-indigo-500/20 text-sm font-medium px-4 py-2 rounded-lg hover:bg-indigo-500/20 transition-colors">
              <Plus className="w-4 h-4" /> {proposal.isTemplate ? "Use Template" : "Duplicate"}
            </button>
            {!proposal.isTemplate && (
              <button onClick={handleSaveAsTemplate} className="flex items-center gap-2 bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 text-sm font-medium px-4 py-2 rounded-lg hover:bg-emerald-500/20 transition-colors">
                <Save className="w-4 h-4" /> Save as Template
              </button>
            )}
            <button onClick={handleDelete} className="flex items-center gap-2 bg-red-500/10 text-red-500 border border-red-500/20 text-sm font-medium px-4 py-2 rounded-lg hover:bg-red-500/20 transition-colors">
              <Trash2 className="w-4 h-4" /> Delete
            </button>
            {proposal.status !== "ACCEPTED" && proposal.status !== "REJECTED" && (
              <button onClick={markAsSent} className="flex items-center gap-2 bg-blue-500/10 text-blue-500 border border-blue-500/20 text-sm font-medium px-4 py-2 rounded-lg hover:bg-blue-500/20 transition-colors">
                <Send className="w-4 h-4" /> {proposal.status === "SENT" ? "Resend via Email" : "Send via Email"}
              </button>
            )}
            <Link href={`/dashboard/crm/proposals/${proposalId}/edit`} className="flex items-center gap-2 bg-white/5 text-white border border-white/10 text-sm font-medium px-4 py-2 rounded-lg hover:bg-white/10 transition-colors">
              <Edit className="w-4 h-4" /> Edit
            </Link>
            <button onClick={handleDownloadPDF} className="flex items-center gap-2 bg-muted text-foreground text-sm font-medium px-4 py-2 rounded-lg hover:bg-muted/80 transition-colors">
              <Download className="w-4 h-4" /> Download PDF
            </button>
          </div>
        </div>

        {/* Proposal Paper UI */}
        <div id="printable-proposal" className="bg-card border border-border/60 rounded-2xl p-10 shadow-sm relative overflow-hidden">
          {/* Header */}
          <div className="flex justify-between items-start mb-12 border-b border-border/40 pb-8">
            <div>
              <div className="flex items-center gap-4 mb-4">
                {org.logoUrl ? (
                  <img 
                    src={org.logoUrl} 
                    alt={org.name} 
                    className="max-h-16 max-w-[220px] w-auto h-auto object-contain object-left"
                    onError={(e) => {
                      (e.currentTarget as HTMLElement).style.display = 'none';
                      const parent = e.currentTarget.parentElement;
                      if (parent) {
                        const fallback = parent.querySelector('.logo-fallback');
                        if (fallback) (fallback as HTMLElement).style.display = 'flex';
                      }
                    }}
                  />
                ) : null}
                <div className={`h-14 px-4 min-w-[56px] bg-[#2DA16D]/20 border border-[#2DA16D]/30 rounded-xl items-center justify-center text-[#2DA16D] font-black text-xl logo-fallback ${org.logoUrl ? 'hidden' : 'flex'}`}>
                  {org.name ? org.name.charAt(0) : 'G'}
                </div>
              </div>
              <h2 className="text-xl font-bold text-foreground">{org.name}</h2>
              {org.billingAddress && <p className="text-sm text-muted-foreground mt-1 whitespace-pre-line">{org.billingAddress}</p>}
              {org.supportEmail && <p className="text-sm text-muted-foreground">{org.supportEmail}</p>}
              {org.website && <p className="text-sm text-muted-foreground">{org.website}</p>}
              {org.phone && <p className="text-sm text-muted-foreground">{org.phone}</p>}
            </div>
            <div className="text-right">
              <span className="inline-block text-[10px] font-bold uppercase tracking-widest px-2.5 py-1 rounded-md bg-[#2DA16D]/10 text-[#2DA16D] border border-[#2DA16D]/20 mb-2">
                Agency Proposal
              </span>
              <p className="text-xl font-bold text-foreground">{proposal.title}</p>
              <div className="mt-4 space-y-1 text-sm">
                <p><span className="text-muted-foreground inline-block w-24 text-left">Date:</span> <span className="font-medium">{format(new Date(proposal.createdAt), 'MMM d, yyyy')}</span></p>
                {proposal.validUntil && (
                  <p><span className="text-muted-foreground inline-block w-24 text-left">Valid Until:</span> <span className="font-medium text-[#E1992D]">{format(new Date(proposal.validUntil), 'MMM d, yyyy')}</span></p>
                )}
              </div>
            </div>
          </div>

          {/* Prepared For */}
          <div className="mb-10 bg-[#2DA16D]/5 border-l-4 border-[#2DA16D] p-5 rounded-r-2xl">
            <h3 className="text-xs font-bold text-[#2DA16D] uppercase tracking-widest mb-2">Prepared For</h3>
            <p className="text-lg font-bold text-foreground">
              {proposal.contact 
                ? `${proposal.contact.firstName} ${proposal.contact.lastName}` 
                : (proposal.lead?.name || "Valued Client")}
            </p>
            {(proposal.contact?.company?.name || proposal.lead?.company) && (
              <p className="text-sm text-muted-foreground mt-0.5 font-medium">
                {proposal.contact?.company?.name || proposal.lead?.company}
              </p>
            )}
            {(proposal.contact?.email || proposal.lead?.email) && (
              <p className="text-sm text-muted-foreground mt-0.5">
                {proposal.contact?.email || proposal.lead?.email}
              </p>
            )}
            {(proposal.contact?.phone || proposal.lead?.phone) && (
              <p className="text-sm text-muted-foreground mt-0.5">
                {proposal.contact?.phone || proposal.lead?.phone}
              </p>
            )}
          </div>

          {/* Line Items */}
          <div className="border border-border/40 rounded-xl overflow-hidden mb-8">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-[#2DA16D] text-white">
                  <th className="py-3 px-4 text-xs font-bold uppercase tracking-wider w-[50%]">Service / Description</th>
                  <th className="py-3 px-4 text-xs font-bold uppercase tracking-wider text-right">Qty</th>
                  <th className="py-3 px-4 text-xs font-bold uppercase tracking-wider text-right">Rate</th>
                  <th className="py-3 px-4 text-xs font-bold uppercase tracking-wider text-right">Disc %</th>
                  <th className="py-3 px-4 text-xs font-bold uppercase tracking-wider text-right">Tax %</th>
                  <th className="py-3 px-4 text-xs font-bold uppercase tracking-wider text-right">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/20">
                {proposal.items?.map((item: any, i: number) => (
                  <tr key={i} className="hover:bg-white/2 transition-colors">
                    <td className="py-4 px-4 text-sm font-medium text-foreground">
                      <div>{item.description}</div>
                    </td>
                    <td className="py-4 px-4 text-sm text-muted-foreground text-right">{item.quantity}</td>
                    <td className="py-4 px-4 text-sm text-muted-foreground text-right font-mono">{symbol}{Number(item.unitPrice || 0).toLocaleString()}</td>
                    <td className="py-4 px-4 text-sm text-[#E1992D] text-right font-mono">{item.discountRate || 0}%</td>
                    <td className="py-4 px-4 text-sm text-muted-foreground text-right font-mono">{item.taxRate || 0}%</td>
                    <td className="py-4 px-4 text-sm font-bold text-foreground text-right font-mono">{symbol}{Number(item.total || (item.quantity * item.unitPrice)).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Totals */}
          {(() => {
            const rawSubtotal = proposal.items?.reduce((sum: number, item: any) => sum + (Number(item.total) || (Number(item.quantity || 1) * Number(item.unitPrice || 0))), 0) || 0;
            const displaySubtotal = (proposal.subtotal && Number(proposal.subtotal) > 0) ? Number(proposal.subtotal) : (rawSubtotal > 0 ? rawSubtotal : Number(proposal.totalAmount || 0));
            return (
              <div className="flex justify-end border-t border-border/60 pt-6 mb-10">
                <div className="w-80 space-y-3 bg-[#2DA16D]/5 p-5 rounded-2xl border border-[#2DA16D]/20">
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span>Subtotal</span>
                    <span className="font-mono text-foreground font-bold">{symbol}{displaySubtotal.toLocaleString()}</span>
                  </div>
                  {(proposal.discountRate > 0) && (
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Overall Discount ({proposal.discountRate}%)</span>
                      <span className="text-[#E1992D] font-mono font-bold">-{symbol}{ (displaySubtotal * (Number(proposal.discountRate) / 100)).toLocaleString() }</span>
                    </div>
                  )}
                  {(proposal.tax > 0) && (
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Tax ({proposal.taxRate || 18}%)</span>
                      <span className="text-foreground font-mono font-bold">{symbol}{Number(proposal.tax).toLocaleString()}</span>
                    </div>
                  )}
                  <div className="flex justify-between items-center text-lg font-bold border-t border-[#2DA16D]/20 pt-3 mt-3">
                    <span className="text-foreground text-sm uppercase tracking-wider">Total Value ({proposal.currency || 'INR'})</span>
                    <span className="text-[#2DA16D] font-mono font-black text-2xl">{symbol}{Number(proposal.totalAmount || displaySubtotal).toLocaleString()}</span>
                  </div>
                </div>
              </div>
            );
          })()}

          {/* Notes */}
          {proposal.notes && (
            <div className="mb-10">
              <div 
                className="prose prose-sm dark:prose-invert max-w-none prose-violet"
                dangerouslySetInnerHTML={{ __html: proposal.notes }}
              />
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
