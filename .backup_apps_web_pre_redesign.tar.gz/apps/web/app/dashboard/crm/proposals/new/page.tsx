"use client"

import { useState, useEffect } from "react"
import { ChevronLeft, Save, Plus, Trash2, Send, Zap, Loader2, PenTool, Sparkles, Globe, Building2, Target, X, ArrowRight, Bot, FileText, FolderOpen } from "lucide-react"
import Link from "next/link"
import { fetchApi, useApi } from "@/lib/useApi"
import { toast } from "sonner"
import { useRouter } from "next/navigation"
import { useOrganization } from "@/context/OrganizationContext"
import { RichTextEditor } from "@/components/ui/RichTextEditor"
import { useCurrency } from "@/hooks/useCurrency"

export default function InteractiveProposalBuilder() {
  const router = useRouter()
  const org = useOrganization()
  const { symbol } = useCurrency()
  const { data: leadsData } = useApi<any>("/crm/leads")
  const leads = leadsData?.data || []

  const { data: contactsData } = useApi<any>("/crm/contacts")
  const contacts = contactsData?.data || []

  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isTemplateModalOpen, setIsTemplateModalOpen] = useState(false)

  // Fetch Templates
  const { data: templatesData, isLoading: isLoadingTemplates } = useApi<any>("/crm/proposals?isTemplate=true")
  const templates = templatesData?.data || []
  
  const [formData, setFormData] = useState({
    title: "Brand Strategy & Web Development",
    leadId: "",
    contactId: "",
    assignToType: "LEAD", // 'LEAD' or 'CONTACT'
    content: "<h2>Overview</h2><p>We are excited to propose a comprehensive brand strategy and website overhaul for your company. Our goal is to position you as the industry leader.</p><h2>Scope of Work</h2><ul><li><strong>Brand Identity Design</strong></li><li><strong>UI/UX Prototyping</strong></li><li><strong>Full-stack Development</strong></li></ul><h2>Timeline</h2><p>This project will take approximately 6 weeks to complete from the signing of this proposal.</p>",
  })

  const [discountRate, setDiscountRate] = useState<number>(0)
  const [taxRate, setTaxRate] = useState<number>(0)

  const [items, setItems] = useState([
    { name: "Brand Identity", description: "Logo, Color Palette, Typography", quantity: 1, unitPrice: 2500, discountRate: 0, taxRate: 0, total: 2500 },
    { name: "Web Development", description: "Frontend and Backend", quantity: 1, unitPrice: 5000, discountRate: 0, taxRate: 0, total: 5000 }
  ])

  const calculateItemTotal = (qty: any, price: any, disc: any, tax: any) => {
    const base = Number(qty) * Number(price);
    const discountAmt = base * (Number(disc || 0) / 100);
    const afterDiscount = base - discountAmt;
    const taxAmt = afterDiscount * (Number(tax || 0) / 100);
    return afterDiscount + taxAmt;
  }

  const calculateSubtotal = () => items.reduce((sum, item) => sum + calculateItemTotal(item.quantity, item.unitPrice, item.discountRate, item.taxRate), 0)
  
  const calculateTotal = () => {
    const subtotal = calculateSubtotal();
    const overallDiscount = subtotal * (Number(discountRate || 0) / 100);
    const afterDiscount = subtotal - overallDiscount;
    const taxAmt = afterDiscount * (Number(taxRate || 0) / 100);
    return afterDiscount + taxAmt;
  }

  const handleAddItem = () => {
    setItems([...items, { name: "New Item", description: "", quantity: 1, unitPrice: 0, discountRate: 0, taxRate: 0, total: 0 }])
  }

  const handleItemChange = (index: number, field: string, value: string | number) => {
    const newItems = [...items]
    const item = newItems[index]
    
    // @ts-ignore
    item[field] = value
    
    if (['quantity', 'unitPrice', 'discountRate', 'taxRate'].includes(field)) {
      item.total = calculateItemTotal(item.quantity, item.unitPrice, item.discountRate, item.taxRate)
    }
    
    setItems(newItems)
  }

  const handleRemoveItem = (index: number) => {
    setItems(items.filter((_, i) => i !== index))
  }

  const handleApplyTemplate = (template: any) => {
    let newContent = template.notes || template.content || ""
    let newTitle = template.title

    // Replace basic dynamic variables based on currently selected client
    let clientName = ""
    if (formData.assignToType === 'LEAD' && formData.leadId) {
      const selectedLead = leads.find((l: any) => l.id === formData.leadId)
      if (selectedLead) clientName = selectedLead.company || selectedLead.name
    } else if (formData.assignToType === 'CONTACT' && formData.contactId) {
      const selectedContact = contacts.find((c: any) => c.id === formData.contactId)
      if (selectedContact) clientName = selectedContact.company?.name || `${selectedContact.firstName} ${selectedContact.lastName}`
    }

    if (clientName) {
      newContent = newContent.replace(/{{client_name}}/g, clientName)
      newContent = newContent.replace(/{{company_name}}/g, clientName)
      newTitle = newTitle.replace(/{{client_name}}/g, clientName)
      newTitle = newTitle.replace(/{{company_name}}/g, clientName)
    }

    setFormData(prev => ({ 
      ...prev, 
      title: newTitle,
      content: newContent
    }))

    if (template.items && Array.isArray(template.items)) {
      setItems(template.items.map((i: any) => ({
        name: i.name || i.description || "Template Item",
        description: i.description || "",
        quantity: Number(i.quantity || 1),
        unitPrice: Number(i.unitPrice || 0),
        discountRate: Number(i.discountRate || 0),
        taxRate: Number(i.taxRate || 0),
        total: calculateItemTotal(i.quantity || 1, i.unitPrice || 0, i.discountRate || 0, i.taxRate || 0)
      })))
    }

    setIsTemplateModalOpen(false)
    toast.success("Template applied successfully!")
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!formData.title.trim()) return toast.error("Proposal title is required")
    if (items.length === 0) return toast.error("Please add at least one line item")

    setIsSubmitting(true)
    try {
      const payload: any = {
        title: formData.title.trim(),
        notes: formData.content,
        discountRate: Number(discountRate || 0),
        taxRate: Number(taxRate || 0),
        items: items.map(item => ({
          description: (item.name || "Item") + (item.description ? ` - ${item.description}` : ''),
          unitPrice: Number(item.unitPrice || 0),
          quantity: Number(item.quantity || 1),
          unit: "units",
          discountRate: Number(item.discountRate || 0),
          taxRate: Number(item.taxRate || 0)
        }))
      };

      if (formData.assignToType === "LEAD" && formData.leadId && formData.leadId.trim() !== "") {
        payload.leadId = formData.leadId.trim();
      }
      if (formData.assignToType === "CONTACT" && formData.contactId && formData.contactId.trim() !== "") {
        payload.contactId = formData.contactId.trim();
      }

      await fetchApi("/crm/proposals", {
        method: "POST",
        body: JSON.stringify(payload)
      })
      toast.success("Interactive Proposal created!")
      router.push("/dashboard/crm/proposals")
    } catch (err: any) {
      toast.error(err.message || "Failed to create proposal")
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="flex flex-col h-full bg-[#050508] text-white overflow-hidden font-sans">
      
      {/* Header */}
      <div className="min-h-16 px-4 md:px-6 py-4 md:py-0 border-b border-white/5 bg-[#0a0a0f] shrink-0 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <Link href="/dashboard/crm/proposals" className="p-2 rounded-lg bg-white/5 border border-white/10 text-slate-400 hover:text-white hover:bg-white/10 transition-colors">
            <ChevronLeft className="w-4 h-4" />
          </Link>
          <div>
            <h1 className="text-lg font-bold tracking-tight">Interactive Proposal Builder</h1>
          </div>
        </div>
        
        <div className="flex items-center gap-3 w-full md:w-auto">
          <button 
            className="flex items-center justify-center gap-2 px-4 py-2 text-sm bg-white/5 text-white font-medium rounded-xl hover:bg-white/10 transition-all border border-white/10 flex-1 md:flex-none"
          >
            <Send className="w-4 h-4" /> Save as Draft
          </button>
          <button 
            onClick={handleSubmit}
            disabled={isSubmitting}
            className="flex items-center justify-center gap-2 px-5 py-2 text-sm bg-violet-600 text-white font-bold rounded-xl hover:bg-violet-700 transition-all shadow-lg shadow-violet-500/20 disabled:opacity-50 flex-1 md:flex-none"
          >
            <Save className="w-4 h-4" />
            {isSubmitting ? "Generating Link..." : "Create Public Link"}
          </button>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        
        {/* Left Column - Controls (50%) */}
        <div className="w-1/2 flex flex-col border-r border-white/5 bg-[#0a0a0f]">
          <div className="flex-1 overflow-y-auto custom-scrollbar p-8 space-y-8">
            
            {/* Settings */}
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-violet-400 font-bold text-sm uppercase tracking-widest mb-4">
                <PenTool className="w-4 h-4" /> 1. Document Settings
              </div>
              
              <div>
                <label className="text-xs text-white/50 mb-1.5 block font-medium">Proposal Title</label>
                <input 
                  value={formData.title} 
                  onChange={e => setFormData({...formData, title: e.target.value})} 
                  placeholder="e.g. Website Redesign & Branding"
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-violet-500/50 transition-colors" 
                />
              </div>
              
              <div>
                <label className="text-xs text-white/50 mb-1.5 block font-medium">Assign to</label>
                <div className="flex gap-2 mb-3">
                  <button type="button" onClick={() => setFormData({...formData, assignToType: 'LEAD', contactId: ''})} className={`flex-1 py-2 text-xs font-bold rounded-lg border transition-colors ${formData.assignToType === 'LEAD' ? 'bg-blue-500/10 border-blue-500/30 text-blue-400' : 'bg-white/5 border-white/10 text-white/50 hover:bg-white/10'}`}>Lead</button>
                  <button type="button" onClick={() => setFormData({...formData, assignToType: 'CONTACT', leadId: ''})} className={`flex-1 py-2 text-xs font-bold rounded-lg border transition-colors ${formData.assignToType === 'CONTACT' ? 'bg-purple-500/10 border-purple-500/30 text-purple-400' : 'bg-white/5 border-white/10 text-white/50 hover:bg-white/10'}`}>Contact</button>
                </div>
                
                {formData.assignToType === 'LEAD' ? (
                  <select 
                    value={formData.leadId} 
                    onChange={e => setFormData({...formData, leadId: e.target.value})} 
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-violet-500/50 transition-colors text-white appearance-none"
                  >
                    <option value="">Select a Lead...</option>
                    {leads.map((lead: any) => (
                      <option key={lead.id} value={lead.id}>{lead.name} ({lead.company || 'No Company'})</option>
                    ))}
                  </select>
                ) : (
                  <select 
                    value={formData.contactId} 
                    onChange={e => setFormData({...formData, contactId: e.target.value})} 
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-violet-500/50 transition-colors text-white appearance-none"
                  >
                    <option value="">Select a Contact...</option>
                    {contacts.map((c: any) => (
                      <option key={c.id} value={c.id}>{c.firstName} {c.lastName} ({c.company?.name || 'No Company'})</option>
                    ))}
                  </select>
                )}
              </div>
            </div>

            {/* Template Content */}
            <div className="pt-4 border-t border-white/5 space-y-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2 text-violet-400 font-bold text-sm uppercase tracking-widest">
                  <PenTool className="w-4 h-4" /> 2. Proposal Content
                </div>
                <button 
                  type="button"
                  onClick={() => setIsTemplateModalOpen(true)}
                  className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-widest bg-white/5 hover:bg-white/10 text-white px-3.5 py-1.5 rounded-lg border border-white/10 transition-all"
                >
                  <FileText className="w-3.5 h-3.5 text-violet-400" />
                  Use Template
                </button>
              </div>
              
              <RichTextEditor 
                content={formData.content} 
                onChange={(html) => setFormData({...formData, content: html})} 
                placeholder="Start typing your proposal content..."
              />
            </div>

            {/* Pricing Table Builder */}
            <div className="pt-4 border-t border-white/5 space-y-4">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2 text-violet-400 font-bold text-sm uppercase tracking-widest">
                  <PenTool className="w-4 h-4" /> 3. Pricing & Modules
                </div>
                <button onClick={handleAddItem} className="flex items-center gap-1 text-xs font-bold text-white/70 hover:text-white bg-white/5 px-3 py-1.5 rounded-lg border border-white/10">
                  <Plus className="w-3 h-3" /> Add Item
                </button>
              </div>

              <div className="space-y-3">
                {items.map((item, index) => (
                  <div key={index} className="p-4 rounded-xl bg-white/5 border border-white/10 relative group">
                    <button 
                      onClick={() => handleRemoveItem(index)}
                      className="absolute -right-2 -top-2 w-6 h-6 bg-rose-500 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-lg"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                    
                    <div className="grid grid-cols-12 gap-3">
                      <div className="col-span-12">
                        <input 
                          type="text" 
                          value={item.name} 
                          onChange={(e) => handleItemChange(index, 'name', e.target.value)}
                          placeholder="Item Name" 
                          className="w-full bg-transparent border-b border-white/10 px-2 py-1 text-sm font-bold focus:outline-none focus:border-violet-500 transition-colors mb-2" 
                        />
                        <input 
                          type="text" 
                          value={item.description} 
                          onChange={(e) => handleItemChange(index, 'description', e.target.value)}
                          placeholder="Description (Optional)" 
                          className="w-full bg-transparent border-b border-white/10 px-2 py-1 text-xs text-slate-400 focus:outline-none focus:border-violet-500 transition-colors" 
                        />
                      </div>
                      
                      <div className="col-span-4 mt-2">
                        <label className="text-[10px] text-white/30 uppercase font-bold block mb-1">Qty</label>
                        <input 
                          type="number" 
                          value={item.quantity} 
                          onChange={(e) => handleItemChange(index, 'quantity', e.target.value)}
                          className="w-full bg-black/50 border border-white/5 rounded-lg px-2 py-1.5 text-sm focus:outline-none text-center" 
                        />
                      </div>
                      <div className="col-span-4 mt-2">
                        <label className="text-[10px] text-white/30 uppercase font-bold block mb-1">Unit Price</label>
                        <input 
                          type="number" 
                          value={item.unitPrice} 
                          onChange={(e) => handleItemChange(index, 'unitPrice', e.target.value)}
                          className="w-full bg-black/50 border border-white/5 rounded-lg px-2 py-1.5 text-sm focus:outline-none" 
                        />
                      </div>
                      <div className="col-span-2 mt-2">
                        <label className="text-[10px] text-white/30 uppercase font-bold block mb-1">Disc %</label>
                        <input 
                          type="number" 
                          value={item.discountRate} 
                          onChange={(e) => handleItemChange(index, 'discountRate', e.target.value)}
                          className="w-full bg-black/50 border border-white/5 rounded-lg px-2 py-1.5 text-sm focus:outline-none" 
                        />
                      </div>
                      <div className="col-span-2 mt-2">
                        <label className="text-[10px] text-white/30 uppercase font-bold block mb-1">Tax %</label>
                        <input 
                          type="number" 
                          value={item.taxRate} 
                          onChange={(e) => handleItemChange(index, 'taxRate', e.target.value)}
                          className="w-full bg-black/50 border border-white/5 rounded-lg px-2 py-1.5 text-sm focus:outline-none" 
                        />
                      </div>
                      <div className="col-span-2 mt-2">
                        <label className="text-[10px] text-white/30 uppercase font-bold block mb-1">Total</label>
                        <div className="w-full bg-black/20 border border-transparent rounded-lg px-2 py-1.5 text-sm text-emerald-400 font-bold flex items-center h-[34px]">
                          {symbol}{item.total.toLocaleString()}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="flex flex-col gap-2 p-4 bg-white/5 border border-white/10 rounded-xl mt-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium text-white/50">Subtotal</span>
                  <span className="text-sm font-bold text-white/70">{symbol}{calculateSubtotal().toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium text-white/50">Overall Discount %</span>
                  <input 
                    type="number" 
                    value={discountRate} 
                    onChange={e => setDiscountRate(Number(e.target.value))}
                    className="w-24 bg-black/50 border border-white/5 rounded px-2 py-1 text-sm text-right focus:outline-none focus:border-violet-500" 
                  />
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium text-white/50">Overall Tax %</span>
                  <input 
                    type="number" 
                    value={taxRate} 
                    onChange={e => setTaxRate(Number(e.target.value))}
                    className="w-24 bg-black/50 border border-white/5 rounded px-2 py-1 text-sm text-right focus:outline-none focus:border-violet-500" 
                  />
                </div>
                <div className="flex justify-between items-center pt-2 border-t border-white/10 mt-1">
                  <span className="font-bold text-violet-400">Total Investment</span>
                  <span className="text-2xl font-black text-white">{symbol}{calculateTotal().toLocaleString()}</span>
                </div>
              </div>
            </div>

          </div>
        </div>

        {/* Right Column - Live Preview (50%) */}
        <div className="w-1/2 bg-[#050508] p-8 flex justify-center overflow-y-auto custom-scrollbar">
          
          <div className="w-full max-w-2xl bg-[#0f0f13] border border-white/5 rounded-2xl p-10 shadow-2xl shadow-black h-max">
            
            {/* Header Preview */}
            <div className="border-b border-white/10 pb-8 mb-8 text-center">
              {/* Dynamic Org Logo */}
              {org.logoUrl ? (
                <img
                  src={org.logoUrl}
                  alt={org.name}
                  className="w-16 h-16 rounded-2xl object-contain mx-auto mb-6 border border-white/10"
                />
              ) : (
                <div className="w-16 h-16 bg-gradient-to-br from-violet-500 to-blue-500 rounded-2xl mx-auto mb-6 flex items-center justify-center shadow-lg shadow-violet-500/20">
                  <span className="text-white font-black text-2xl">{(org.name ?? 'G').charAt(0).toUpperCase()}</span>
                </div>
              )}
              <h1 className="text-3xl font-bold text-white mb-2">{formData.title || "Proposal Title"}</h1>
              <p className="text-slate-400">Prepared for: {leads.find((l:any) => l.id === formData.leadId)?.company || 'Client Name'}</p>
            </div>

            {/* HTML Content Preview */}
            <div 
              className="prose prose-invert prose-violet max-w-none mb-12"
              dangerouslySetInnerHTML={{ __html: formData.content }}
            />

            {/* Pricing Table Preview */}
            <div>
              <h2 className="text-xl font-bold text-white mb-6 border-b border-white/5 pb-2">Investment Breakdown</h2>
              
              <div className="rounded-xl border border-white/10 overflow-hidden bg-black/20">
                <table className="w-full text-sm text-left">
                  <thead className="bg-white/5 text-xs uppercase text-slate-400 border-b border-white/10">
                    <tr>
                      <th className="px-6 py-4 font-bold">Module / Phase</th>
                      <th className="px-6 py-4 font-bold text-right">Qty</th>
                      <th className="px-6 py-4 font-bold text-right">Price</th>
                      <th className="px-6 py-4 font-bold text-right">Disc %</th>
                      <th className="px-6 py-4 font-bold text-right">Tax %</th>
                      <th className="px-6 py-4 font-bold text-right">Total</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {items.map((item, i) => (
                      <tr key={i} className="hover:bg-white/5 transition-colors">
                        <td className="px-6 py-4">
                          <p className="font-bold text-white">{item.name || 'Item Name'}</p>
                          {item.description && <p className="text-xs text-slate-500 mt-1">{item.description}</p>}
                        </td>
                        <td className="px-6 py-4 text-right text-slate-300">{item.quantity}</td>
                        <td className="px-6 py-4 text-right text-slate-300">{symbol}{Number(item.unitPrice).toLocaleString()}</td>
                        <td className="px-6 py-4 text-right text-slate-300">{item.discountRate}%</td>
                        <td className="px-6 py-4 text-right text-slate-300">{item.taxRate}%</td>
                        <td className="px-6 py-4 text-right font-medium text-white">{symbol}{item.total.toLocaleString()}</td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr className="bg-violet-600/10 border-t border-white/10">
                      <td colSpan={5} className="px-6 py-4 text-right font-bold text-violet-400">Total Investment</td>
                      <td className="px-6 py-4 text-right font-black text-white text-lg">{symbol}{calculateTotal().toLocaleString()}</td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>

            {/* Mock Signature Block */}
            <div className="mt-16 pt-8 border-t border-white/10">
              <div className="flex gap-12">
                <div className="flex-1">
                  <div className="h-16 border-b-2 border-white/10 mb-2"></div>
                  <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">Client Signature</p>
                </div>
                <div className="flex-1">
                  <div className="h-16 border-b-2 border-white/10 mb-2 flex items-end pb-2">
                    <span className="font-medium text-white">{org.name}</span>
                  </div>
                  <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">Agency Signature</p>
                  {(org.phone || org.website) && (
                    <p className="text-xs text-slate-400 mt-1">
                      {org.phone && <span>{org.phone}</span>}
                      {org.phone && org.website && <span> | </span>}
                      {org.website && <span>{org.website}</span>}
                    </p>
                  )}
                </div>
              </div>
            </div>

          </div>
        </div>

      </div>

      {/* TEMPLATE SELECTION MODAL */}
      {isTemplateModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-2xl bg-[#0e0e14] border border-white/10 rounded-2xl shadow-2xl p-6 md:p-8 relative overflow-hidden flex flex-col max-h-[85vh]">
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-amber-500 to-orange-500" />
            
            <div className="flex items-start justify-between mb-6 shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-violet-500/10 border border-violet-500/20 flex items-center justify-center text-violet-400">
                  <FolderOpen className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white flex items-center gap-2">
                    Proposal Templates
                  </h3>
                  <p className="text-xs text-white/50">Select a pre-built template to instantly populate your proposal.</p>
                </div>
              </div>
              <button 
                onClick={() => setIsTemplateModalOpen(false)}
                className="p-1.5 rounded-lg bg-white/5 text-white/40 hover:text-white hover:bg-white/10 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="overflow-y-auto custom-scrollbar pr-2 flex-1 space-y-3">
              {isLoadingTemplates ? (
                <div className="flex items-center justify-center py-10">
                  <Loader2 className="w-6 h-6 animate-spin text-white/30" />
                </div>
              ) : templates.length === 0 ? (
                <div className="text-center py-10 bg-white/5 rounded-xl border border-white/5 border-dashed">
                  <p className="text-sm text-white/50 mb-2">No templates found.</p>
                  <p className="text-xs text-white/30">Save an existing proposal as a template to see it here.</p>
                </div>
              ) : (
                templates.map((tpl: any) => (
                  <div key={tpl.id} className="p-4 bg-white/5 border border-white/10 hover:border-amber-500/30 rounded-xl transition-all group flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                      <h4 className="font-bold text-sm text-white mb-1">{tpl.title}</h4>
                      <p className="text-xs text-white/50 line-clamp-1">{tpl.notes?.replace(/<[^>]*>?/gm, '') || 'No content'}</p>
                    </div>
                    <button
                      onClick={() => handleApplyTemplate(tpl)}
                      className="shrink-0 px-4 py-2 bg-amber-500/10 text-amber-400 hover:bg-amber-500 hover:text-white text-xs font-bold rounded-lg transition-colors border border-amber-500/20"
                    >
                      Use Template
                    </button>
                  </div>
                ))
              )}
            </div>

            <div className="mt-6 pt-4 border-t border-white/5 flex items-center justify-end gap-3 shrink-0">
              <button
                type="button"
                onClick={() => setIsTemplateModalOpen(false)}
                className="px-4 py-2 text-xs font-bold text-white/60 hover:text-white bg-white/5 rounded-xl transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
